

台式机常用SSDT

|      |                  |           |
| :--: | :--------------- | :-------- |
| 序号 | 名称             | 作用      |
|  1   | SSDT-AWAC.aml    | RTC       |
|  2   | SSDT-EC-USBX.aml | USB电源   |
|  3   | SSDT-PLUG.aml    | CPU变频   |
|  4   | SSDT-PMC.aml     | 模拟Nvram |