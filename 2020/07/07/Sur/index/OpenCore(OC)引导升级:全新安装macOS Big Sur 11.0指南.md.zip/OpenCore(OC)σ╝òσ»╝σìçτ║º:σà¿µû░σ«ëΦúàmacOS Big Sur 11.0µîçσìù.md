

<img src="https://shuiyunxc.gitee.io/images/full-logo-light.svg" alt="full-logo-light" style="zoom:25%;" />





## OpenCore（OC）引导升级/全新安装macOS Big Sur 11.0指南



### 关键字：OpenCore；OC；升级安装；全新安装；macOS Big Sur 11.0；黑苹果

### 摘要：

随着OpenCore（OC）代码的更新，目前（07月06日以后的编译版）已经可以支持macOS Big Sur 11.0的升级安装与全新安装，无需其他辅助！适用于6、7、8、9、10代CPU。

### 前期准备：

- 可以用[OpenCore（OC）](https://gitee.com/shuiyunxc/OpenCore)07月06日以后的编译版，正常进入10.15.5，没有任何明显异常或不稳定，各项功能正常。这个是先决条件。[OpenCore下载](https://gitee.com/shuiyunxc/OpenCore)
- 准备一个U盘，抹盘格式：FAT32，方案：主引导记录，将上面的EFI拷贝至U盘根目录下，用PlistEdit Pro或其他类似软件打开config配置文件（暂时不要用OCC编辑）。这样做的目的是不用每次都去挂载EFI分区，直接可以修改。
- `Config-Misc- Security-ScanPolicy`：0
- `Config-Misc-BlessOverride`：\System\Library\CoreServices\boot.efi（此项安装的时候很有必要，安装完成后可以取消）
- `Config-NVRAM-添加（Add）-7C436110-AB2A-4BBB-A880-FE41995C9F82`：引导参数添加-V，
- 台式机带集显的BIOS开启，config集显参数只用一个0300913E（适用于9代CPU，其他自行搜索）
- 只有集显的，安装时只用一个0700913E/0700923E，或其他适合自己的参数，其他先删除。
- 必须使用`FakeSMC.kext`驱动

### 镜像准备：

[macOS Big Sur 11.0（20A4299v）下载文档](https://shuiyunxc.gitee.io/2020/07/07/Sur/index/macOS-Big-Sur-11.0(20A4299v).pdf)

[macOS Big Sur 11.0（20A4300b）下载文档](https://shuiyunxc.gitee.io/2020/07/07/Sur/index/macOS-Big-Sur-11.0(20A4300b).pdf)

### 安装U盘制作：

- 镜像直接放应用程序，抹掉U盘，格式：扩展日志，方案：GUID，名字：2（各自习惯自己修改）
- 打开终端，输入：B1的代码：`sudo /Applications/Install\ macOS\ Beta.app/Contents/Resources/createinstallmedia --volume /Volumes/2`。B2的代码：`sudo /Applications/Install\ macOS\ Big\ Sur\ Beta.app/Contents/Resources/createinstallmedia --volume /Volumes/2` （需要特别注意volume前面是2个“-”，拷贝复制的时候会变为一个“-”，导致错误）。
- 回车，输入密码，输入Y回车，等待写入完成。注意需要这个U盘是安装U盘，不是上面说的EFI的U盘。

### 开始安装：

用EFI的U盘引导安装盘，正常情况下，是可以进入到安装界面。

如果出现无限循环XPC的情况，重启，做一次Cleannvram。再引导安装盘。

最好安装到一个全新的硬盘。全盘抹盘安装。安装到已有的硬盘或分区，可能出现各种问题。

安装过程就不多说了，一般会有4个阶段的重启，耐心等待，前3次都是默认的那个install的盘。最后一次是安装的目标盘（有2个名字一样的，一般是前面那个）

最后一次，基本是设置阶段。与10.15.5么有多大差异。然后进入系统。

### 安装后各项功能：

- Wi-Fi正常，
- 蓝牙正常，
- 声卡正常，
- 定位正常，
- APP下载正常，
- 信息正常，
- FaceTime正常，
- 睡眠正常，
- USB正常，
- 大部分常用软件正常，
- 目前的OC引导无法进入恢复盘，待OC后续更新解决

### 完成安装后的部分截图：

<img src="/Volumes/123/Blog/xiucaiee/source/_posts/Sur/index/QWE-12.08.38.png" alt="QWE-12.08.38" style="zoom:100%;" />

<img src="https://shuiyunxc.gitee.io/2020/07/07/Sur/index/QWE-12.51.57.png" alt="QWE-12.51.57" style="zoom:100%;" />

<img src="https://shuiyunxc.gitee.io/2020/07/07/Sur/index/QWE-12.09.55.png" alt="QWE-12.09.55" style="zoom:50%;" /><img src="https://shuiyunxc.gitee.io/2020/07/07/Sur/index/QWE-12.10.10.png" alt="QWE-12.10.10" style="zoom:50%;" />

<img src="https://shuiyunxc.gitee.io/2020/07/07/Sur/index/QWE-12.10.28.png" alt="QWE-12.10.28" style="zoom:50%;" />

<img src="https://shuiyunxc.gitee.io/2020/07/07/Sur/index/QWE-12.10.37.png" alt="QWE-12.10.37" style="zoom:50%;" />

<img src="https://shuiyunxc.gitee.io/2020/07/07/Sur/index/QWE-12.10.52.png" alt="QWE-12.10.52" style="zoom:50%;" /><img src="https://shuiyunxc.gitee.io/2020/07/07/Sur/index/QWE-12.11.11.png" alt="QWE-12.11.11" style="zoom:50%;" />

<img src="https://shuiyunxc.gitee.io/2020/07/07/Sur/index/QWE-12.49.51.png" alt="QWE-12.49.51" style="zoom:50%;" />

<img src="https://shuiyunxc.gitee.io/2020/07/07/Sur/index/QWE-12.09.38.png" alt="QWE-12.09.38" style="zoom:50%;" />

<img src="https://shuiyunxc.gitee.io/2020/07/07/Sur/index/QWE-12.09.21.png" alt="QWE-12.09.21" style="zoom:100%;" />

### 结束语

希望这篇Blog，能给大家鼓舞和启迪！！如有遗漏或不妥之处请指出，[付费服务请参阅](https://item.taobao.com/item.htm?spm=a1z10.1-c.w4004-2823137787.2.6b8e2834JCa3dX&id=522904735703)

<img src="https://img.shields.io/badge/更新日期：-2020年07月09日-red?style=flat-square" align='center'>

#### <font color= "#FF0000"  align="center"> 黑苹果OpenCore开放群，群号:9422866，注明“独行秀才Blog引入”</font>